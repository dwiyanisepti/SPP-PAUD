<div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg order-lg-first">
                <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                    <li class="nav-item">
                        <a href="<?php echo e(route('web.index')); ?>" class="nav-link <?php echo e(set_active(['web.*'], 'active')); ?>">
                            <i class="fe fe-home"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('spp.index')); ?>" class="nav-link <?php echo e(set_active(['spp.*'], 'active')); ?>">
                            <i class="fe fe-repeat"></i> Transaksi SPP
                        </a>
                    </li>
                    <li class="nav-item">
                            <a href="<?php echo e(route('tabungan.index')); ?>" class="nav-link <?php echo e(set_active(['tabungan.*'], 'active')); ?>">
                            <i class="fe fe-repeat"></i> Tabungan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('keuangan.index')); ?>" class="nav-link <?php echo e(set_active(['keuangan.*'], 'active')); ?>">
                            <i class="fe fe-repeat"></i> Keuangan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('tagihan.index')); ?>" class="nav-link <?php echo e(set_active(['tagihan.*'], 'active')); ?>">
                            <i class="fe fe-box"></i> Tagihan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('siswa.index')); ?>" class="nav-link <?php echo e(set_active(['siswa.*'], 'active')); ?>">
                            <i class="fe fe-users"></i> Siswa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('kelas.index')); ?>" class="nav-link <?php echo e(set_active(['kelas.*'], 'active')); ?>">
                            <i class="fe fe-box"></i>Kelas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('periode.index')); ?>" class="nav-link <?php echo e(set_active(['periode.*'], 'active')); ?>">
                            <i class="fe fe-box"></i> Periode
                        </a>
                    </li>
                    <li class="nav-item">
                            <a href="<?php echo e(route('kuitansi.index')); ?>" class="nav-link <?php echo e(set_active(['kuitansi.*'], 'active')); ?>">
                            <i class="fe fe-folder"></i> Kuitansi
                        </a>
                    </li>
                    <?php if(Auth::user()->role == 'Admin' || Auth::user()->role == 'SuperAdmin'): ?>
                    <li class="nav-item">
                            <a href="<?php echo e(route('user.index')); ?>" class="nav-link <?php echo e(set_active(['user.*'], 'active')); ?>">
                            <i class="fe fe-box"></i> Pengguna
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('buku.panduan')); ?>" class="nav-link <?php echo e(set_active(['buku.*'], 'active')); ?>">
                        <i class="fe fe-book"></i> Buku Panduan
                    </a>
                </li>
                </ul>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\spp\resources\views/shared/navbar.blade.php ENDPATH**/ ?>