<?php $__env->startSection('site-name','Sistem Informasi SPP'); ?>
<?php $__env->startSection('page-name', (isset($tagihan) ? 'Ubah Tagihan' : 'Tagihan Baru')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-8">
            <form action="<?php echo e((isset($tagihan) ? route('tagihan.update', $tagihan->id) : route('tagihan.create'))); ?>" method="post" class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('page-name'); ?></h3>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="form-label">Nama</label>
                                <input type="text" class="form-control" name="nama" placeholder="Nama" value="<?php echo e(isset($tagihan) ? $tagihan->nama : old('nama')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Jumlah</label>
                                <input type="number" class="form-control" name="jumlah" value="<?php echo e(isset($tagihan) ? $tagihan->jumlah : old('jumlah')); ?>" required>
                            </div>
                            <div class="form-group">
                                <div class="form-label">Peserta</div>
                                <div class="custom-switches-stacked">
                                <label class="custom-switch">
                                <input type="radio" name="peserta" value="1" class="custom-switch-input" <?php echo e(isset($tagihan) ? ($tagihan->wajib_semua == 1 ? 'checked' : '') : 'checked'); ?>>
                                <span class="custom-switch-indicator"></span>
                                <span class="custom-switch-description">Wajib Semua Siswa</span>
                                </label>
                                <label class="custom-switch">
                                <input type="radio" name="peserta" value="2" class="custom-switch-input" <?php echo e(isset($tagihan) ? (($tagihan->kelas_id != null) ? 'checked' : '') : ''); ?>>
                                <span class="custom-switch-indicator"></span>
                                <span class="custom-switch-description">Hanya Kelas</span>
                                </label>
                                <label class="custom-switch">
                                <input type="radio" name="peserta" value="3" class="custom-switch-input" <?php echo e(isset($tagihan) ? (($tagihan->kelas_id == null && $tagihan->wajib_semua == null) ? 'checked' : '') : ''); ?>>
                                <span class="custom-switch-indicator"></span>
                                <span class="custom-switch-description">Hanya Siswa</span>
                                </label>
                            </div>
                            </div>
                            <div class="form-group" style="display: <?php echo e(isset($tagihan) ? (($tagihan->kelas_id != null) ? 'block' : 'none') : 'none'); ?>" id="form-kelas">
                                <label class="form-label">Kelas</label>
                                <select class="form-control" name="kelas_id" id="hanya-kelas">
                                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e(isset($tagihan) ? (($tagihan->kelas_id == $item->id) ? 'selected' : '') : ''); ?>>
                                            <?php echo e($item->nama); ?> - <?php echo e(isset($item->periode) ? $item->periode->nama : ''); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group" style="display: <?php echo e(isset($tagihan) ? (($tagihan->kelas_id == null && $tagihan->wajib_semua == null) ? 'block' : 'none') : 'none'); ?>" id="form-siswa">
                                <label class="form-label">Siswa</label>
                                <select class="form-control" name="siswa_id[]" id="hanya-siswa" multiple>
                                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e(isset($tagihan) ? (($tagihan->wajib_semua == null && $tagihan->kelas_id == null) ? (in_array($item->id, $tagihan->siswa->pluck('id')->toArray()) ? 'selected' : '') : '') : ''); ?>>
                                            <?php echo e($item->nama); ?> - <?php echo e($item->kelas->nama); ?> <?php echo e(isset($item->kelas->periode) ? "(". $item->kelas->periode->nama .")" : ''); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <div class="d-flex">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-link">Batal</a>
                        <button type="submit" class="btn btn-primary ml-auto">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/select2/select2.min.css')); ?>" rel="stylesheet" />
    <style>
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            color: black;
        }
        .select2{
            width: 100% !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    require(['jquery', 'selectize','select2'], function ($, selectize) {
        $(document).ready(function () {
            $('#select-beast').selectize({});
        });
        $('#hanya-kelas').select2({
            placeholder: "Pilih Kelas",
        });
        $('#hanya-siswa').select2({
            placeholder: "Pilih Siswa",
        });

        $('.custom-switch-input').change(function(){
            if(this.value == 2){
                $('#form-kelas').show()
                $('#form-siswa').hide()

                $('#hanya-kelas').prop('required', true)
                $('#hanya-siswa').prop('required', false)
            }else if(this.value == 3){
                $('#form-kelas').hide()
                $('#form-siswa').show()

                $('#hanya-kelas').prop('required', false)
                $('#hanya-siswa').prop('required', true)
            }else{
                $('#form-kelas').hide()
                $('#form-siswa').hide()

                $('#hanya-kelas').prop('required', false)
                $('#hanya-siswa').prop('required', false)
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spp\resources\views/tagihan/form.blade.php ENDPATH**/ ?>