<?php $__env->startSection('page-name','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <iframe src="<?php echo e(asset('manualbook.pdf')); ?>" frameborder="0" class="col-12" style="min-height: 800px"></iframe>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spp\resources\views/panduan/buku.blade.php ENDPATH**/ ?>